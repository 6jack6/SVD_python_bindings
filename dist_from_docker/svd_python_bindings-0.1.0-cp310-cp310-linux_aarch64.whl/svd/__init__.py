"""Python-friendly entry point for the C++ SVD bindings."""

from pathlib import Path
import sys

_package_dir = Path(__file__).resolve().parent
_repo_root = _package_dir.parent.parent
_dev_build_dir = _repo_root / "build" / "svd"
if _dev_build_dir.exists():
    sys.path.insert(0, str(_dev_build_dir))
    try:
        __path__  # type: ignore  # noqa: F821
    except NameError:
        __path__ = []  # type: ignore  # pragma: no cover
    __path__.append(str(_dev_build_dir))  # type: ignore

from .svd_bindings import svd  # noqa: F401

__all__ = ["svd"]

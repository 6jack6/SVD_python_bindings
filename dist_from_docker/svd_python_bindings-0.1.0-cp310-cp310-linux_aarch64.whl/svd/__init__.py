"""Python-friendly entry point for the C++ SVD bindings."""

from pathlib import Path

_package_dir = Path(__file__).resolve().parent
_repo_root = _package_dir.parent.parent
_dev_build_dir = _repo_root / "build" / "svd"
if _dev_build_dir.exists():
    # Allow running directly from the source tree without installing the wheel.
    __path__.append(str(_dev_build_dir))

from .svd_bindings import svd  # type: ignore

__all__ = ["svd"]
